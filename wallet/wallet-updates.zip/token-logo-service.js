/**
 * Comprehensive Token Logo Service
 * Fetches logos for all tokens and networks from CoinGecko and other sources
 */

class TokenLogoService {
    constructor() {
        this.logoCache = new Map();
        this.networkLogos = new Map();
        this.initializeNetworkLogos();
        this.initializeCommonTokenLogos();
    }

    /**
     * Initialize network logos
     */
    initializeNetworkLogos() {
        this.networkLogos.set('cheese-native', {
            logo: './icon-192.png',
            name: 'Native Chain',
            emoji: '🧀'
        });
        this.networkLogos.set('bsc', {
            logo: 'https://assets.coingecko.com/coins/images/825/small/bnb-icon2_2x.png',
            name: 'Binance Smart Chain',
            emoji: '🔵'
        });
        this.networkLogos.set('ethereum', {
            logo: 'https://assets.coingecko.com/coins/images/279/small/ethereum.png',
            name: 'Ethereum',
            emoji: '💎'
        });
        this.networkLogos.set('tron', {
            logo: 'https://assets.coingecko.com/coins/images/1094/small/tron-logo.png',
            name: 'Tron',
            emoji: '🔴'
        });
    }

    /**
     * Initialize common token logos (CoinGecko URLs)
     */
    initializeCommonTokenLogos() {
        // Common tokens with known CoinGecko IDs
        const commonLogos = {
            // Native tokens
            'NCHEESE': './icon-192.png',
            'CHEESE': '', // Will be fetched from PancakeSwap (handled in token-search.js)
            
            // Stablecoins
            'USDT': 'https://assets.coingecko.com/coins/images/325/small/Tether.png',
            'USDC': 'https://assets.coingecko.com/coins/images/6319/small/USD_Coin_icon.png',
            'BUSD': 'https://assets.coingecko.com/coins/images/9576/small/BUSD.png',
            'DAI': 'https://assets.coingecko.com/coins/images/9956/small/dai-multi-collateral-mcd.png',
            'TUSD': 'https://assets.coingecko.com/coins/images/3449/small/tusd.png',
            
            // Major cryptocurrencies
            'BTC': 'https://assets.coingecko.com/coins/images/1/small/bitcoin.png',
            'ETH': 'https://assets.coingecko.com/coins/images/279/small/ethereum.png',
            'BNB': 'https://assets.coingecko.com/coins/images/825/small/bnb-icon2_2x.png',
            'WBNB': 'https://assets.coingecko.com/coins/images/825/small/bnb-icon2_2x.png',
            'WBTC': 'https://assets.coingecko.com/coins/images/7598/small/wrapped_bitcoin_wbtc.png',
            'TRX': 'https://assets.coingecko.com/coins/images/1094/small/tron-logo.png',
            
            // DeFi tokens
            'CAKE': 'https://assets.coingecko.com/coins/images/12632/small/pancakeswap-cake-logo.png',
            'UNI': 'https://assets.coingecko.com/coins/images/12504/small/uniswap-uni.png',
            'LINK': 'https://assets.coingecko.com/coins/images/877/small/chainlink-new-logo.png',
            'AAVE': 'https://assets.coingecko.com/coins/images/12645/small/AAVE.png',
            'SUSHI': 'https://assets.coingecko.com/coins/images/12271/small/512x512_Logo_no_bg.png',
            
            // Other popular tokens
            'DOGE': 'https://assets.coingecko.com/coins/images/5/small/dogecoin.png',
            'SHIB': 'https://assets.coingecko.com/coins/images/11939/small/shiba.png',
            'MATIC': 'https://assets.coingecko.com/coins/images/4713/small/matic-token-icon.png',
            'ADA': 'https://assets.coingecko.com/coins/images/975/small/cardano.png',
            'SOL': 'https://assets.coingecko.com/coins/images/4128/small/solana.png',
            'DOT': 'https://assets.coingecko.com/coins/images/12171/small/polkadot.png',
            'AVAX': 'https://assets.coingecko.com/coins/images/12559/small/avalanche-avax-logo.png'
        };

        Object.entries(commonLogos).forEach(([symbol, logo]) => {
            this.logoCache.set(symbol.toUpperCase(), logo);
        });
    }

    /**
     * Get network logo
     */
    getNetworkLogo(networkId) {
        const network = this.networkLogos.get(networkId);
        return network ? network.logo : null;
    }

    /**
     * Get network info (logo, name, emoji)
     */
    getNetworkInfo(networkId) {
        return this.networkLogos.get(networkId) || {
            logo: null,
            name: networkId,
            emoji: '🌐'
        };
    }

    /**
     * Get token logo - tries multiple sources
     */
    async getTokenLogo(symbol, chain = null, contractAddress = null) {
        const symbolUpper = symbol?.toUpperCase();
        
        // Check cache first
        if (this.logoCache.has(symbolUpper)) {
            return this.logoCache.get(symbolUpper);
        }

        // Special handling for NCHEESE
        if (symbolUpper === 'NCHEESE') {
            return './icon-192.png';
        }

        // Try CoinGecko API
        try {
            const coinGeckoId = this.getCoinGeckoId(symbolUpper);
            if (coinGeckoId) {
                const logo = await this.fetchLogoFromCoinGecko(coinGeckoId);
                if (logo) {
                    this.logoCache.set(symbolUpper, logo);
                    return logo;
                }
            }
        } catch (error) {
            console.warn(`Failed to fetch logo from CoinGecko for ${symbolUpper}:`, error);
        }

        // Try contract address lookup (for BSC/Ethereum tokens)
        if (contractAddress && (chain === 'bsc' || chain === 'ethereum' || chain === 'tron')) {
            try {
                const logo = await this.fetchLogoFromContract(contractAddress, chain);
                if (logo) {
                    this.logoCache.set(symbolUpper, logo);
                    return logo;
                }
            } catch (error) {
                console.warn(`Failed to fetch logo from contract for ${symbolUpper}:`, error);
            }
        }

        // Fallback: Generate placeholder or return null
        return null;
    }

    /**
     * Get CoinGecko ID for a token symbol
     */
    getCoinGeckoId(symbol) {
        const symbolMap = {
            'USDT': 'tether',
            'USDC': 'usd-coin',
            'BUSD': 'binance-usd',
            'DAI': 'dai',
            'ETH': 'ethereum',
            'BTC': 'bitcoin',
            'BNB': 'binancecoin',
            'WBNB': 'binancecoin',
            'WBTC': 'wrapped-bitcoin',
            'CAKE': 'pancakeswap-token',
            'TRX': 'tron',
            'TRON': 'tron',
            'DOGE': 'dogecoin',
            'SHIB': 'shiba-inu',
            'MATIC': 'matic-network',
            'ADA': 'cardano',
            'SOL': 'solana',
            'DOT': 'polkadot',
            'AVAX': 'avalanche-2',
            'UNI': 'uniswap',
            'LINK': 'chainlink',
            'AAVE': 'aave',
            'SUSHI': 'sushi'
        };
        return symbolMap[symbol?.toUpperCase()] || null;
    }

    /**
     * Fetch logo from CoinGecko API
     */
    async fetchLogoFromCoinGecko(coinGeckoId) {
        try {
            const response = await fetch(`https://api.coingecko.com/api/v3/coins/${coinGeckoId}?localization=false&tickers=false&market_data=false&community_data=false&developer_data=false&sparkline=false`);
            if (response.ok) {
                const data = await response.json();
                if (data.image && data.image.small) {
                    return data.image.small;
                }
            }
        } catch (error) {
            console.warn('CoinGecko API error:', error);
        }
        return null;
    }

    /**
     * Fetch logo from contract (BSCScan/Etherscan/TronScan)
     */
    async fetchLogoFromContract(contractAddress, chain) {
        // This would require API keys for BSCScan/Etherscan
        // For now, return null - logos should be fetched via CoinGecko or manual addition
        return null;
    }

    /**
     * Get token logo synchronously (from cache only)
     */
    getTokenLogoSync(symbol, chain = null) {
        const symbolUpper = symbol?.toUpperCase();
        
        // Check cache
        if (this.logoCache.has(symbolUpper)) {
            return this.logoCache.get(symbolUpper);
        }

        // Special handling
        if (symbolUpper === 'NCHEESE') {
            return './icon-192.png';
        }

        // Return null if not in cache (will trigger async fetch)
        return null;
    }

    /**
     * Set token logo manually (for user-added tokens)
     */
    setTokenLogo(symbol, logoURI) {
        const symbolUpper = symbol?.toUpperCase();
        this.logoCache.set(symbolUpper, logoURI);
    }
}

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = TokenLogoService;
}

