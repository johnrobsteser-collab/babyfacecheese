/**
 * Swap Engine - Token Swapping Functionality
 * Handles CHEESE token swaps
 */

class SwapEngine {
    constructor(blockchainAPI, founderIncome = null) {
        this.api = blockchainAPI;
        this.founderIncome = founderIncome;
        // CRITICAL: Use liquidity pool address instead of SWAP_CONTRACT
        // Liquidity pool wallet: 0x96e12d8940672fcb8067cab30100b1d9dd48a1e5
        this.liquidityPoolAddress = '0x96e12d8940672fcb8067cab30100b1d9dd48a1e5';
        this.swapRates = {
            'NCHEESE/USDT': 1.0,
            'NCHEESE/USDC': 1.0,
            'NCHEESE/BNB': 0.001,
            // Legacy support
            'CHEESE/USDT': 1.0,
            'CHEESE/USDC': 1.0,
            'CHEESE/BNB': 0.001
        };
        this.swapFee = 0.005; // 0.5% swap fee
    }

    // Get swap rate
    getSwapRate(fromToken, toToken) {
        const pair = `${fromToken}/${toToken}`;
        const reversePair = `${toToken}/${fromToken}`;
        
        if (this.swapRates[pair]) {
            return this.swapRates[pair];
        } else if (this.swapRates[reversePair]) {
            return 1 / this.swapRates[reversePair];
        }
        
        return 1.0; // Default 1:1 rate
    }

    // Calculate swap amount
    calculateSwapAmount(fromAmount, fromToken, toToken) {
        const rate = this.getSwapRate(fromToken, toToken);
        const grossAmount = fromAmount * rate;
        const fee = grossAmount * this.swapFee;
        const netAmount = grossAmount - fee;
        
        return {
            fromAmount,
            toAmount: netAmount,
            rate,
            fee,
            feePercent: this.swapFee * 100
        };
    }

    // Execute swap
    async executeSwap(fromAmount, fromToken, toToken, walletAddress, privateKey) {
        try {
            // CRITICAL: Handle cross-chain swaps (NCHEESE → CHEESE)
            // CHEESE is a BSC token, so swapping NCHEESE → CHEESE requires bridging
            const isCrossChainSwap = (fromToken === 'NCHEESE' && toToken === 'CHEESE') ||
                                    (fromToken === 'CHEESE' && toToken === 'NCHEESE');
            
            if (isCrossChainSwap && fromToken === 'NCHEESE' && toToken === 'CHEESE') {
                // NCHEESE → CHEESE: Need to bridge to BSC
                return await this.executeCrossChainSwapToBSC(fromAmount, walletAddress, privateKey);
            } else if (isCrossChainSwap && fromToken === 'CHEESE' && toToken === 'NCHEESE') {
                // CHEESE → NCHEESE: Need to bridge from BSC
                return await this.executeCrossChainSwapFromBSC(fromAmount, walletAddress, privateKey);
            }
            
            // Regular same-chain swap (e.g., NCHEESE → USDT on native chain)
            // Validate balance
            const balance = await this.api.getBalance(walletAddress);
            if (balance < fromAmount) {
                throw new Error('Insufficient balance');
            }

            // Calculate swap
            const swapCalc = this.calculateSwapAmount(fromAmount, fromToken, toToken);

            // Create swap transaction
            const swapTransaction = {
                type: 'swap',
                from: walletAddress,
                fromToken: fromToken,
                fromAmount: fromAmount,
                toToken: toToken,
                toAmount: swapCalc.toAmount,
                rate: swapCalc.rate,
                fee: swapCalc.fee,
                timestamp: Date.now()
            };

            // Send swap amount (minus fee) to liquidity pool
            const swapAmount = swapCalc.toAmount;
            const result = await this.api.sendTransaction(
                walletAddress,
                this.liquidityPoolAddress, // Liquidity pool address (not treasury)
                swapAmount,
                privateKey,
                swapTransaction
            );

            // Route swap fee to founder wallet
            let feeTx = null;
            if (this.founderIncome && swapCalc.fee > 0) {
                feeTx = await this.founderIncome.routeSwapFee(
                    swapCalc.fee,
                    walletAddress,
                    privateKey,
                    result.transaction?.id || result.transaction?.hash
                );
            }

            return {
                success: true,
                transaction: result,
                feeTransaction: feeTx,
                swapDetails: swapCalc
            };
        } catch (error) {
            console.error('Swap error:', error);
            throw error;
        }
    }
    
    // Execute cross-chain swap: NCHEESE → CHEESE (native to BSC)
    async executeCrossChainSwapToBSC(fromAmount, walletAddress, privateKey) {
        try {
            console.log(`🔄 Executing cross-chain swap: ${fromAmount} NCHEESE → CHEESE (BSC)`);
            
            // Validate balance
            const balance = await this.api.getBalance(walletAddress);
            if (balance < fromAmount) {
                throw new Error('Insufficient NCHEESE balance');
            }

            // Calculate swap (1:1 ratio for NCHEESE → CHEESE)
            const swapCalc = this.calculateSwapAmount(fromAmount, 'NCHEESE', 'CHEESE');
            const cheeseAmount = swapCalc.toAmount; // Amount of CHEESE to receive on BSC

            // Step 1: Lock NCHEESE on native blockchain (deduct from user)
            const swapTransaction = {
                type: 'swap_cross_chain',
                from: walletAddress,
                fromToken: 'NCHEESE',
                fromAmount: fromAmount,
                toToken: 'CHEESE',
                toAmount: cheeseAmount,
                toChain: 'BSC',
                rate: swapCalc.rate,
                fee: swapCalc.fee,
                timestamp: Date.now()
            };

            // Deduct NCHEESE from user (send to swap lock address)
            const swapLockAddress = `SWAP_LOCK_BSC_${Date.now()}`;
            const result = await this.api.sendTransaction(
                walletAddress,
                swapLockAddress,
                fromAmount, // Lock full amount
                privateKey,
                swapTransaction
            );

            if (!result.success) {
                throw new Error('Failed to lock NCHEESE tokens');
            }

            // Step 2: Transfer CHEESE tokens on BSC
            // CRITICAL: This requires a backend service or smart contract
            // For now, we'll send a request to the blockchain API to handle BSC transfer
            try {
                const transferResult = await this.transferCheeseOnBSC(
                    walletAddress, 
                    cheeseAmount, 
                    result.transaction?.id || result.transaction?.hash
                );
                
                if (transferResult.success) {
                    console.log(`✅ CHEESE tokens transferred on BSC: ${cheeseAmount} CHEESE to ${walletAddress}`);
                } else {
                    console.warn('⚠️ BSC transfer failed, swap record saved for manual processing:', transferResult.error);
                }
            } catch (bscError) {
                console.error('Error transferring CHEESE on BSC:', bscError);
                // Continue - swap record will be saved for manual processing
            }

            // Save swap record for tracking
            const swapRecord = {
                ...swapTransaction,
                transactionHash: result.transaction?.id || result.transaction?.hash,
                status: 'completed',
                lockedNCHEESE: fromAmount,
                cheeseToReceive: cheeseAmount,
                cheeseTransferred: cheeseAmount,
                bscAddress: walletAddress,
                timestamp: Date.now()
            };

            this.saveSwapRecord(swapRecord);

            // Route swap fee to founder wallet
            let feeTx = null;
            if (this.founderIncome && swapCalc.fee > 0) {
                feeTx = await this.founderIncome.routeSwapFee(
                    swapCalc.fee,
                    walletAddress,
                    privateKey,
                    result.transaction?.id || result.transaction?.hash
                );
            }

            return {
                success: true,
                transaction: result,
                feeTransaction: feeTx,
                swapDetails: swapCalc,
                crossChain: true,
                toToken: 'CHEESE',
                toAmount: cheeseAmount,
                swapRecord: swapRecord,
                message: `✅ Swap completed! ${cheeseAmount} CHEESE tokens have been added to your BSC wallet.`
            };
        } catch (error) {
            console.error('Cross-chain swap error:', error);
            throw error;
        }
    }
    
    // Transfer CHEESE tokens on BSC (requires backend API endpoint)
    async transferCheeseOnBSC(recipientAddress, amount, swapTxHash) {
        try {
            // CRITICAL: This should call your blockchain API to transfer CHEESE on BSC
            // The API needs to have access to a treasury wallet with CHEESE tokens
            const apiUrl = this.api.baseUrl || 'https://cheese-blockchain-131552958027.asia-southeast1.run.app';
            
            const response = await fetch(`${apiUrl}/api/swap/transfer-cheese`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    recipient: recipientAddress,
                    amount: amount,
                    swapTxHash: swapTxHash,
                    chain: 'BSC'
                })
            });

            if (response.ok) {
                const data = await response.json();
                return { success: true, data: data };
            } else {
                const error = await response.json();
                return { success: false, error: error.message || 'Transfer failed' };
            }
        } catch (error) {
            console.error('Error calling transfer API:', error);
            return { success: false, error: error.message };
        }
    }
    
    // Execute cross-chain swap: CHEESE → NCHEESE (BSC to native)
    async executeCrossChainSwapFromBSC(fromAmount, walletAddress, privateKey) {
        // This would require the user to have CHEESE on BSC and lock it
        // Then mint NCHEESE on native chain
        throw new Error('CHEESE → NCHEESE swap requires CHEESE tokens on BSC. Please use bridge system instead.');
    }
    
    // Save swap record for tracking
    saveSwapRecord(swapRecord) {
        try {
            const existing = JSON.parse(localStorage.getItem('cheeseSwapRecords') || '[]');
            existing.push(swapRecord);
            localStorage.setItem('cheeseSwapRecords', JSON.stringify(existing));
            console.log('💾 Saved swap record:', swapRecord);
        } catch (error) {
            console.error('Error saving swap record:', error);
        }
    }
    
    // Get pending swaps that need CHEESE tokens on BSC
    getPendingSwaps(walletAddress) {
        try {
            const allSwaps = JSON.parse(localStorage.getItem('cheeseSwapRecords') || '[]');
            return allSwaps.filter(swap => 
                swap.from === walletAddress && 
                swap.status === 'pending' &&
                swap.toToken === 'CHEESE' &&
                swap.toChain === 'BSC'
            );
        } catch (error) {
            console.error('Error getting pending swaps:', error);
            return [];
        }
    }

    // Get swap history
    async getSwapHistory(walletAddress) {
        const transactions = await this.api.getTransactionHistory(walletAddress);
        return transactions.filter(tx => tx.data && tx.data.type === 'swap');
    }

    // Update swap rates (could fetch from API or liquidity pool)
    updateSwapRates(rates) {
        this.swapRates = { ...this.swapRates, ...rates };
    }
}

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SwapEngine;
}


